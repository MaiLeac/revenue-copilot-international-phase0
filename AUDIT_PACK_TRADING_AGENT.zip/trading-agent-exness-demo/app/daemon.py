"""Autonomous Trading Daemon (Milestone M2) — Runs on Windows Host with MT5 Terminal.

Monitors enabled symbols, checks Data Quality Gate, evaluates quantitative strategy,
places demo orders with hard SL/TP, and records state to run_state.json and LIVE_DEMO_JOURNAL.md.
Controlled by setting 'command' in run_state.json ('start' | 'stop').
"""

from __future__ import annotations

import json
import logging
import os
import sys
import time
from dataclasses import asdict
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

AGENT_ROOT = Path(__file__).resolve().parents[1]
if str(AGENT_ROOT) not in sys.path:
    sys.path.insert(0, str(AGENT_ROOT))

REPO_ROOT = Path(__file__).resolve().parents[2]
if str(REPO_ROOT) not in sys.path:
    sys.path.insert(0, str(REPO_ROOT))

from app.config import load_config
from app.data.quality_gate import DataQualityGate, DataQualityError, is_market_closed_weekend
from app.logging_setup import setup_logging
from app.mt5.connection import MT5ConnectionManager, MT5ConnectionError, LiveAccountBlockedError
from app.mt5.market_data import MT5MarketDataReader
from app.mt5.execution import DemoExecutionAdapter, OrderResult
from app.risk.kill_switch import KillSwitch
from app.risk.manager import RiskManager
from app.strategies.trend_pullback import TrendFollowingPullbackStrategy

STATE_FILE = AGENT_ROOT / "run_state.json"
JOURNAL_FILE = AGENT_ROOT / "research" / "LIVE_DEMO_JOURNAL.md"
KILL_SWITCH_FILE = AGENT_ROOT / "kill_switch_state.json"
RISK_STATE_FILE = AGENT_ROOT / "risk_state.json"


def load_run_state() -> dict[str, Any]:
    if STATE_FILE.exists():
        try:
            return json.loads(STATE_FILE.read_text(encoding="utf-8"))
        except Exception:
            pass
    return {
        "status": "STOPPED",
        "active": False,
        "command": "start",
        "last_heartbeat_utc": None,
        "account": None,
        "open_positions": [],
        "recent_trades": [],
    }


def save_run_state(state: dict[str, Any]) -> None:
    """Atomic write for state persistence (AUDIT-07)."""
    temp_file = STATE_FILE.with_suffix(".tmp")
    temp_file.write_text(json.dumps(state, indent=2, ensure_ascii=False), encoding="utf-8")
    temp_file.replace(STATE_FILE)


def append_journal_entry(title: str, content: str) -> None:
    now_str = datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M:%S UTC")
    entry = f"\n### [{now_str}] {title}\n{content}\n"
    if not JOURNAL_FILE.exists():
        JOURNAL_FILE.write_text("# Money HQ Live Demo Trading Journal\n", encoding="utf-8")
    with JOURNAL_FILE.open("a", encoding="utf-8") as f:
        f.write(entry)


def send_alert_safe(msg: str) -> None:
    try:
        from tools.telegram_notify import send_telegram_alert
        send_telegram_alert(msg)
    except Exception as e:
        logging.getLogger("trading_agent.daemon").warning(f"Failed to send Telegram alert: {e}")


def run_daemon_loop(config_path: str = "config/demo.yaml", loop_interval_sec: int = 30) -> None:
    logger = setup_logging(os.environ.get("LOG_LEVEL", "INFO"))
    logger.info("Initializing Autonomous Trading Daemon on Windows host...")

    config = load_config(AGENT_ROOT / config_path)
    kill_switch = KillSwitch(enabled=config.safety.kill_switch, state_file=KILL_SWITCH_FILE)
    risk_mgr = RiskManager(config=config, kill_switch=kill_switch, state_file=RISK_STATE_FILE)
    conn = MT5ConnectionManager(config=config)

    account_meta = conn.connect()
    reader = MT5MarketDataReader(connection=conn, config=config)
    gate = DataQualityGate(config=config)
    adapter = DemoExecutionAdapter(config=config, connection=conn, kill_switch=kill_switch)
    strategy = TrendFollowingPullbackStrategy()

    logger.info(
        f"Connected to MT5 Demo: #{account_meta.login} ({account_meta.server}) Balance=${account_meta.balance:.2f} "
        f"| Strategy: {strategy.strategy_id} v{strategy.version}"
    )

    state = load_run_state()
    state["status"] = "RUNNING"
    state["active"] = True
    state["account"] = asdict(account_meta)

    # Reconcile open positions from MT5 terminal upon startup (AUDIT-08)
    initial_positions = adapter.get_open_positions()
    state["open_positions"] = [
        {
            "ticket": p.ticket,
            "symbol": p.symbol,
            "type": "BUY" if p.type == 0 else "SELL",
            "volume": p.volume,
            "price_open": p.price_open,
            "sl": p.sl,
            "tp": p.tp,
            "profit": p.profit,
        }
        for p in initial_positions
    ]
    logger.info(f"Reconciled {len(initial_positions)} open positions from MT5 terminal on startup.")
    save_run_state(state)

    append_journal_entry(
        "Daemon Started",
        f"- **Account:** #{account_meta.login} ({account_meta.server})\n"
        f"- **Balance:** ${account_meta.balance:.2f} {account_meta.currency}\n"
        f"- **Mode:** {config.execution_mode}\n"
        f"- **Enabled Symbols:** {', '.join(config.symbols.enabled) or 'None'}\n"
    )

    send_alert_safe(
        f"🚀 <b>AUTONOMOUS TRADING DAEMON KHỞI ĐỘNG!</b>\n\n"
        f"• Tài khoản: <code>#{account_meta.login}</code> (Demo)\n"
        f"• Server: <code>{account_meta.server}</code>\n"
        f"• Vốn ảo: <b>${account_meta.balance:,.2f} USD</b>\n"
        f"• Cặp theo dõi: <code>{', '.join(config.symbols.enabled)}</code>\n"
        f"• Rủi ro/lệnh: <b>{config.risk.risk_per_trade_pct}%</b>\n"
        f"• Trạng thái: Đang quét thị trường..."
    )

    last_processed_candles: dict[str, str] = {}

    try:
        while True:
            state = load_run_state()
            if state.get("command") == "stop":
                logger.info("Received 'stop' command. Halting daemon.")
                state["status"] = "STOPPED"
                state["active"] = False
                save_run_state(state)
                send_alert_safe("⏹️ <b>AUTONOMOUS TRADING DAEMON ĐÃ TẠM DỪNG!</b>")
                break

            now_utc = datetime.now(timezone.utc)
            state["last_heartbeat_utc"] = now_utc.isoformat()

            if state.get("command") == "pause":
                if state.get("status") != "PAUSED":
                    logger.info("Received 'pause' command. Pausing trade scan.")
                    state["status"] = "PAUSED"
                    state["active"] = False
                    send_alert_safe("⏸️ <b>AUTONOMOUS TRADING DAEMON ĐÃ TẠM DỪNG QUÉT (PAUSED)!</b>")
                save_run_state(state)
                time.sleep(loop_interval_sec)
                continue
            elif state.get("command") == "start" and state.get("status") == "PAUSED":
                state["status"] = "RUNNING"
                state["active"] = True
                logger.info("Resumed trading daemon from pause.")
                send_alert_safe("▶️ <b>AUTONOMOUS TRADING DAEMON ĐÃ TIẾP TỤC QUÉT TÍN HIỆU!</b>")

            # Update account info and enforce Risk Manager (AUDIT-05)
            try:
                acc_info = conn.read_account_metadata()
                state["account"] = asdict(acc_info)
                risk_state = risk_mgr.evaluate_equity(acc_info.equity)
                state["risk"] = {
                    "daily_pnl_pct": round(risk_state.daily_pnl_pct, 2),
                    "drawdown_pct": round(risk_state.drawdown_pct, 2),
                    "peak_equity": round(risk_state.peak_equity, 2),
                    "day_start_equity": round(risk_state.day_start_equity, 2),
                }
            except Exception as e:
                logger.warning(f"Could not refresh account info or evaluate risk: {e}")

            # Check open positions
            try:
                positions = adapter.get_open_positions()
                pos_list = []
                for p in positions:
                    pos_list.append({
                        "ticket": p.ticket,
                        "symbol": p.symbol,
                        "type": "BUY" if p.type == 0 else "SELL",
                        "volume": p.volume,
                        "price_open": p.price_open,
                        "sl": p.sl,
                        "tp": p.tp,
                        "profit": p.profit,
                    })
                state["open_positions"] = pos_list
            except Exception as e:
                logger.warning(f"Could not read open positions: {e}")

            # Enforce Session Filter: active trading window (London + NY overlap, e.g. 07:00-16:00 UTC)
            if config.session.enabled and not (config.session.start_hour_utc <= now_utc.hour < config.session.end_hour_utc):
                logger.info(
                    f"Session Filter: Current time {now_utc.strftime('%H:%M')} UTC is outside "
                    f"active window ({config.session.start_hour_utc:02d}:00-{config.session.end_hour_utc:02d}:00 UTC). "
                    "Skipping market scan."
                )
                save_run_state(state)
                time.sleep(loop_interval_sec)
                continue

            # Scan enabled symbols (EURUSD pilot)
            for base_sym in config.symbols.enabled:
                try:
                    spec = reader.read_symbol_spec(base_sym)
                    tick = reader.read_tick(base_sym)
                    h4_candles = reader.read_candles(base_sym, "H4", count=60)
                    h1_candles = reader.read_candles(base_sym, "H1", count=60)

                    # Quality gate check on H1 candles
                    gate.evaluate(base_sym, "H1", tick, h1_candles, now_utc=now_utc)

                    # Guarantee candle bar idempotency (AUDIT-03) on closed H1 bar
                    last_bar_time = h1_candles[-1].open_time_utc.isoformat()
                    if last_processed_candles.get(base_sym) == last_bar_time:
                        continue

                    # Evaluate 4-tier H4/H1 trend pullback strategy
                    signal = strategy.evaluate(base_sym, h4_candles, h1_candles)
                    if signal.direction in ("BUY", "SELL"):
                        logger.info(f"Signal detected for {spec.broker_symbol}: {signal.direction} @ {signal.entry_price} ({signal.reason})")
                        # Place order
                        order_res: OrderResult = adapter.place_order(signal, spec)
                        if order_res.success:
                            last_processed_candles[base_sym] = last_bar_time
                            trade_msg = (
                                f"📈 <b>VÀO LỆNH DEMO THÀNH CÔNG!</b>\n\n"
                                f"• Mã: <b>{order_res.symbol}</b>\n"
                                f"• Chiến thuật: <b>H4/H1 Trend-Following Pullback</b>\n"
                                f"• Chiều: <b>{order_res.direction}</b>\n"
                                f"• Khối lượng: <b>{order_res.volume} lot</b>\n"
                                f"• Giá khớp: <b>{order_res.price}</b>\n"
                                f"• Chặn lỗ (SL): <code>{order_res.stop_loss}</code>\n"
                                f"• Chốt lời (TP): <code>{order_res.take_profit}</code>\n"
                                f"• Vé lệnh: <code>#{order_res.ticket}</code>\n"
                                f"• Lý do: <i>{signal.reason}</i>"
                            )
                            send_alert_safe(trade_msg)
                            append_journal_entry(
                                f"Order Executed: {order_res.direction} {order_res.symbol}",
                                f"- **Ticket:** #{order_res.ticket}\n"
                                f"- **Volume:** {order_res.volume} lots @ {order_res.price}\n"
                                f"- **SL:** {order_res.stop_loss} | **TP:** {order_res.take_profit}\n"
                                f"- **Signal Reason:** {signal.reason}\n"
                            )
                            state["recent_trades"].append(asdict(order_res))

                except DataQualityError as dqe:
                    if is_market_closed_weekend(base_sym, now_utc):
                        pass # Normal weekend closure, wait silently
                    else:
                        logger.warning(f"Data quality error for {base_sym}: {dqe}")
                except Exception as e:
                    logger.warning(f"Scan error on {base_sym}: {e}")

            save_run_state(state)
            time.sleep(loop_interval_sec)

    except KeyboardInterrupt:
        logger.info("Daemon interrupted by user.")
    finally:
        state["status"] = "STOPPED"
        state["active"] = False
        save_run_state(state)
        conn.shutdown()
        logger.info("Daemon shutdown cleanly.")


if __name__ == "__main__":
    run_daemon_loop()
